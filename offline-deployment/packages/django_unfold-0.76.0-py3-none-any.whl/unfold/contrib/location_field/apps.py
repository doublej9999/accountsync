from django.apps import AppConfig


class DefaultAppConfig(AppConfig):
    name = "unfold.contrib.location_field"
    label = "unfold_location_field"
