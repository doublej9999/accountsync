from django.apps import AppConfig


class DefaultAppConfig(AppConfig):
    name = "unfold.contrib.forms"
    label = "unfold_forms"
